interface CarType {
  vehicleRegistrationNumber: string;
  timeOfEntry: string | Date;
  accumulatedCharge: number;
  discount: number | null;
  totalCharge: number;
}

export default CarType;
