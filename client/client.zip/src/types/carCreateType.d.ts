interface CarCreateType {
  regNumber: string;
  timeOfAdmission: string | Date;
  vehicleType: string;
  discount: string;
}

export default CarCreateType;
