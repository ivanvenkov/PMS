const discountTypes = {
  Silver: 1,
  Gold: 2,
  Platinum: 3
};

export default discountTypes;
