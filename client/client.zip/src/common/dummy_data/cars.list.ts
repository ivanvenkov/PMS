export const carsList = [
  {
    vehicleRegistrationNumber: 'CA1111',
    timeOfEntry: '2023-03-13T10:50:27.154',
    accumulatedCharge: 25,
    discount: 2.5,
    totalCharge: 22.5
  },
  {
    vehicleRegistrationNumber: 'CA2222',
    timeOfEntry: '2023-03-13T14:50:27.154',
    accumulatedCharge: 26,
    discount: 3.9,
    totalCharge: 22.1
  },
  {
    vehicleRegistrationNumber: 'CA3333',
    timeOfEntry: '2023-03-13T14:50:27.154',
    accumulatedCharge: 52,
    discount: 10.4,
    totalCharge: 41.6
  }
];

