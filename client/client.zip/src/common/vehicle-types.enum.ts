const vehicleTypes = {
  CarsAndMotorcycles : 1,
  Vans : 2,
  BusAndTrucks : 3
}

export default vehicleTypes;

